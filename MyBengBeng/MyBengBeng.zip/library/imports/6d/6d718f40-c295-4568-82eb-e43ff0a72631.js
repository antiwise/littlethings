"use strict";
cc._RF.push(module, '6d7189AwpVFaILr5D/wpyYx', 'gameUIscr');
// Script/GameUI/gameUIscr.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        gameover: cc.Node,
        gamenext: cc.Node,
        gamerestart: cc.Node,
        xingdonghua: cc.Animation,
        clickaudio: cc.AudioSource
    },

    Gameover: function Gameover() {
        gameState = 3; //死亡
        this.gameover.active = true;
    },
    Gamenext: function Gamenext() {
        gameState = 4; //成功
        this.gamenext.active = true;
        if (heroData.xingxing == 3) {
            this.xingdonghua.play("guankaxingxing3");
        };
        if (heroData.xingxing == 2) {
            this.xingdonghua.play("guankaxingxing2");
        };
        if (heroData.caidan) {
            this.gamenext.getChildByName('caidan').active = true;
        };
    },
    onclicksound: function onclicksound() {
        this.clickaudio.play();
    },
    onclickres: function onclickres() {
        this.gamerestart.active = true;
    },
    onclickresclose: function onclickresclose() {
        this.gamerestart.active = false;
    },
    Onclickbegin: function Onclickbegin() {
        q_moshi = 1;
        var xx = new chushi();
        cc.director.loadScene("game");
    },
    //点击无限模式

    Onclicknext: function Onclicknext() {
        q_moshi = 1;
        q_xuanzheguanka++;
        var xx = new chushi();
        cc.director.loadScene("game");
    },
    //点击开始下一关


    Onclickhome: function Onclickhome() {
        cc.director.loadScene("mainScence");
    }
} //点击无限模式


);

cc._RF.pop();