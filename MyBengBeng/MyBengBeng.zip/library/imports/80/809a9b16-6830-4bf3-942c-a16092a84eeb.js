"use strict";
cc._RF.push(module, '809a9sWaDBL85QsoWCSqE7r', 'Getbone');
// Script/Getbone.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {

        _armature: null,
        _armatureDisplay: null,
        bone: []

    },

    // LIFE-CYCLE CALLBACKS:

    init: function init() {
        this._armatureDisplay = this.getComponent(dragonBones.ArmatureDisplay);
        this._armature = this._armatureDisplay.armature();
        this.huoqubone();
    },
    huoqubone: function huoqubone() {
        var j;
        for (var i = 0; i < 9; i++) {
            j = i + 1;
            this.bone[i] = this._armature.getBone("bone" + j);
        }
    }
});

cc._RF.pop();