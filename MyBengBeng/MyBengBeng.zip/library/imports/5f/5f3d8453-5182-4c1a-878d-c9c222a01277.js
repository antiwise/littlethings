"use strict";
cc._RF.push(module, '5f3d8RTUYJMGoeNycIioBJ3', 'paihangbtnscr');
// Script/UIScr/paihangbtnscr.js

'use strict';

var self;
cc.Class({
    extends: cc.Component,

    properties: {
        mingci: cc.Label,
        touxiang: cc.Sprite,
        mingcheng: cc.Label,
        defen: cc.Label,
        caidannode: cc.Node,
        xingxingnode: cc.Node
    },

    onLoad: function onLoad() {
        self = this;
    },
    init: function init(mingci, data, leixing) {
        this.mingci.string = mingci;
        this.mingcheng.string = data.nikename;
        var grade = data.KVDataList.length != 0 ? data.KVDataList[0].value : 0;
        this.defen.string = grade.toString();
        this.createImage(avatarUrl);
        if (leixing == 'star') this.xingxingnode.active = true;else this.caidannode.active = true;
    },
    createImage: function createImage(avatarUrl) {
        try {
            cc.loader.load({
                url: avatarUrl, type: 'jpg'
            }, function (err, texture) {
                self.touxiang.spriteFrame = new cc.SpriteFrame(texture);
            });
        } catch (err) {};
    }
});

cc._RF.pop();