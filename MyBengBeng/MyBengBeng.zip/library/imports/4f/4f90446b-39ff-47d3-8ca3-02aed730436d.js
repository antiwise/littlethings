"use strict";
cc._RF.push(module, '4f904RrOf9H04yjAq7XMENt', 'Girlscr');
// Script/Girlscr.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    start: function start() {}
});

cc._RF.pop();