/**
 * Created by Administrator on 2018/4/28.
 */
var https = require('https');
var ws = require('ws');
var app = require('express')();
var config = require('../config')
var http = require('../utils/http')
var fs = require('fs')
var path = require('path')

var WebSocketServer = require('../utils/WebSocketServer')
var WXBizDataCrypt = require('./WXBizDataCrypt')

var WebServer = new WebSocketServer(config).httpsServer;

var auth_url = 'https://api.weixin.qq.com/sns/jscode2session?appid={0}&secret={1}&js_code={2}&grant_type=authorization_code'
WebServer.get('/login',function(req,res){
    var code =req.query.code;
    var url = auth_url.format(config.appid,config.appsecret,code);
    Logger.info('url:',url);
    http.get(url,{},function(err,body){
        if(err){
            Logger.error('error:',err);
            res.send({code:100,msg:'请求失败'})
        } else {
            var data = JSON.parse(body);
            res.send({code:0,msg:'请求成功',openid:data.openid,session_key:data.session_key})
            Logger.info('body:',body)
        }
    })
});

WebServer.get('/encode',function(req,res){
    console.log('encode:',req.query);
    if(!req.query.sessionKey || !req.query.encryptedData || !req.query.iv){
        return res.send({code:100,msg:'缺少参数'})
    } else {
        var sessionKey = decodeURIComponent(req.query.sessionKey)
        try{
            var pc = new WXBizDataCrypt(config.appid, sessionKey)
            var data = pc.decryptData(decodeURIComponent(req.query.encryptedData) , decodeURIComponent(req.query.iv));
            console.log('解密后 data: ', data)
            res.send({code:0,data:data})
        }catch(e){
            res.send({code:101})
        }
    }
});

WebServer.get('/shareModel',function(req,res){
    console.log('encode:',req.query);
    var share = fs.readFileSync(path.join(__dirname, "../share.json"));
    res.send({code:0,data:share})
});


// var appId = "wxb52dabb4ae6c5e5f";
// var sessionKey = "Av/kbm77la18Bo+vDfg9Hw==";
// var encryptedData = "wtv8PmAjj/ht48phniECl6DlLjar8OuIC9ghKH6yyNmo6FzHQIKc4/Rf3BkvHdWgT62ogUvxjMkmVFUvOpkKpFMYZ5YFk6Nd3MghV8kdrWLuf5XnoqGLkFhI+LVTkhlbeGF3UQZCIn4N0wfnvbjnWTrdiUaqJRyMz7vh0xggRPL3PHcaIb5oyYrV349xsb4gyzeKPpTRC9ED3o4Yf+SPLExfdiTBnaZ1OaYsdqsVirgh60Z7OxTmXVUAsedbSJZ4z4+nJvbkE/63Twb/a8+64ByPhojwMSsqJru5mLFFIZ+LEf250K+sqfbMhvWnmAYdQLy0ZcSKKqXzFZMmZGa56V5IdRQc8jo4gYVzrhuxbynQghQcjpRYDLDdUUWn5alAg8ruQ6D7uM1qygGbluASixUR59w59UP2QGplgDOXCazC90NB/0ZokvrATObKXpixiUgMu+azL9pEUgCoi1mxaMp47mpl5zyGCAuDoG/54cQ=";
// var iv = "7vXKt43CYsQwntPHIImz0Q==";

// var key = 'NZD+wHStkwJb7uV9YDTjOQ==';
// var iv = 'Ml0DkuylauJWk859UoMgaw==';
// var data = 'SwlfsYA4yDS7WoYmuuAftZZkGZuHRz6W6br0qvpUBrbk2M+stEZIyJBRhPBKJUYGXWNrUVMy8buckYpLDjvtU6WJIGdZP91bBQL9eQ6oLY7xFwrgXQPkvjaPWLXubpGJ9i2ossWa4PRt+v51rBVzrA=='
//
//
// var pc = new WXBizDataCrypt(config.appid, key)
// data = pc.decryptData(data , iv);
// console.log('解密后 data: ', data)

